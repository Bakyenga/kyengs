<table width="100%" border="0" cellspacing="0" cellpadding="0" class="footerbg">
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td align="center" class="smallbodytext">&copy;<?php echo date('Y');?> Automated Cargo Route and Vehicle Management and its partners. All Rights Reserved.</td>
        </tr>
      </table>
